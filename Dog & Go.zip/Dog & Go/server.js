const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const sqlite3 = require("sqlite3").verbose(); // Importa o módulo sqlite3
const multer = require("multer");
const app = express();
const path = require("path");
const port = 3000;

// Configurações do servidor
app.use(cors()); // Habilita requisições de qualquer origem
app.use(bodyParser.json());

let idUsuario = null;
let Nome = null;
let IdDog = null; 
let NomeDog = null;

// Configurando o servidor para servir a pasta uploads
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Conexão com o banco de dados SQLite
const db = new sqlite3.Database("./DBClientes.db", (err) => {
  if (err) {
    console.error("Erro ao conectar ao banco de dados:", err.message);
  } else {
    console.log("Conectado ao banco de dados SQLite.");
  }
});

// Configuração do armazenamento de arquivos
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Pasta onde a imagem será salva
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Nome único para o arquivo
  },
});

const upload = multer({ storage: storage });

// Criação da tabela se não existir
db.run(
  `CREATE TABLE IF NOT EXISTS dbclientes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        usuario TEXT NOT NULL UNIQUE,
        senha TEXT NOT NULL
    )`,
  (err) => {
    if (err) {
      console.error("Erro ao criar tabela:", err.message);
    } else {
      console.log("Tabela dbclientes pronta para uso.");
    }
  }
);

// Rota para exibir o formulário (opcional)
app.get("./CriarContaCliente.html", (req, res) => {
  res.sendFile(__dirname + "/CriarContaCliente.html"); // Caminho para o arquivo HTML
});

// Rota para receber os dados do formulário e salvar no banco de dados
app.post("/cadastrar", (req, res) => {
  const { nome, email, usuario, senha } = req.body;

  // Validação dos campos
  if (!nome || !email || !usuario || !senha) {
    return res
      .status(400)
      .json({ message: "Todos os campos são obrigatórios!" });
  }

  // Inserir os dados no banco de dados
  const query = `INSERT INTO dbclientes (nome, email, usuario, senha) VALUES (?, ?, ?, ?)`;
  db.run(query, [nome, email, usuario, senha], function (err) {
    if (err) {
      console.error("Erro ao inserir dados:", err.message);
      return res
        .status(500)
        .json({ message: "Erro ao salvar os dados no banco de dados." });
    }

    console.log(`Cadastro realizado com sucesso! ID: ${this.lastID}`);
    res.json({ message: "Cadastro realizado com sucesso!" });
  });
});

let usuarioLogado = null;

// Rota para exibir o formulário de login
app.get("/LoginCliente.html", (req, res) => {
  res.sendFile(__dirname + "/LoginCliente.html"); // Caminho para o arquivo HTML de login
});

// Rota para processar o login
app.post("/login", (req, res) => {
  const { usuario, senha } = req.body;

  // Validação dos campos
  if (!usuario || !senha) {
    return res
      .status(400)
      .json({ message: "Usuário e senha são obrigatórios!" });
  }

  // Verificar se o usuário e senha estão corretos no banco de dados
  const query = `SELECT * FROM dbclientes WHERE usuario = ? AND senha = ?`;
  db.get(query, [usuario, senha], (err, row) => {
    if (err) {
      console.error("Erro ao buscar dados no banco de dados:", err.message);
      return res
        .status(500)
        .json({ message: "Erro no servidor. Tente novamente mais tarde." });
    }

    if (row) {
      // Login bem-sucedido: armazenar os dados do usuário no servidor
      usuarioLogado = {
        id: row.id,
        nome: row.nome,
        email: row.email,
        usuario: row.usuario,
        senha: row.senha, // Evite salvar senhas em produção; isso é só para teste
      };

      idUsuario = usuarioLogado.id; // Atribuição global
      Nome = usuarioLogado.nome
      console.log(idUsuario); // Saída: 123

      console.log("Usuário logado:", usuarioLogado);

      return res.json({
        message: "Login bem-sucedido!",
        user: usuarioLogado, // Enviar os dados do usuário para o cliente
      });
    } else {
      // Login falhou
      return res.status(401).json({ message: "Usuário ou senha inválidos!" });
    }
  });
});

// Rota para exibir o dashboard (caso necessário)
app.get("/DashCliente.html", (req, res) => {
  res.sendFile(__dirname + "/DashCliente.html"); // Caminho para o arquivo HTML do dashboard
});

// Supondo que "Nome" é a variável global no banco
app.get('/getUserName', (req, res) => {
    if (Nome) {
        res.json({ nome: Nome });
    } else {
        res.status(404).json({ error: 'Nome não encontrado' });
    }
});


let coordenadasRecebidas = [];

// Rota para salvar as coordenadas
app.post("/salvarCoordenadas", (req, res) => {
  const { lat, lng } = req.body;

  // Verifica se as coordenadas são válidas
  if (typeof lat !== "number" || typeof lng !== "number") {
    console.error("Erro: Coordenadas inválidas recebidas:", req.body);
    return res.status(400).json({ error: "Coordenadas inválidas!" });
  }

  // Adiciona as coordenadas ao array e faz log
  const novaCoordenada = {
    latitude: lat,
    longitude: lng,
    timestamp: new Date(),
  };
  coordenadasRecebidas.push(novaCoordenada);

  console.log("Coordenadas recebidas e salvas:", novaCoordenada);
  console.log("Lista atualizada de coordenadas:", coordenadasRecebidas);

  res.status(201).json({ message: "Coordenadas salvas com sucesso!" });
});

// Rota para listar as coordenadas (opcional para debug)
app.get("/coordenadas", (req, res) => {
  console.log(
    "Rota /coordenadas acessada. Coordenadas atuais:",
    coordenadasRecebidas
  );
  res.status(200).json(coordenadasRecebidas);
});

// Daqui pra baixo, só dogwalker

// Criação da tabela se não existir
db.run(
  `CREATE TABLE IF NOT EXISTS dogwalkers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        usuario TEXT NOT NULL UNIQUE,
        senha TEXT NOT NULL
    )`,
  (err) => {
    if (err) {
      console.error("Erro ao criar tabela:", err.message);
    } else {
      console.log("Tabela dogwalkers pronta para uso.");
    }
  }
);

// Rota para exibir o formulário (opcional)
app.get("/CriarContaDogWalker.html", (req, res) => {
  res.sendFile(__dirname + "/CriarContaDogWalker.html"); // Caminho para o arquivo HTML
});

// Rota para receber os dados do formulário e salvar no banco de dados
app.post("/cadastrarwalker", (req, res) => {
  const { nome, email, usuario, senha } = req.body;

  // Validação dos campos
  if (!nome || !email || !usuario || !senha) {
    return res
      .status(400)
      .json({ message: "Todos os campos são obrigatórios!" });
  }

  // Inserir os dados no banco de dados
  const query = `INSERT INTO dogwalkers (nome, email, usuario, senha) VALUES (?, ?, ?, ?)`;
  db.run(query, [nome, email, usuario, senha], function (err) {
    if (err) {
      console.error("Erro ao inserir dados:", err.message);
      return res
        .status(500)
        .json({ message: "Erro ao salvar os dados no banco de dados." });
    }

    console.log(`Cadastro realizado com sucesso! ID: ${this.lastID}`);
    res.json({ message: "Cadastro realizado com sucesso!" });
  });
});

let usuarioLogado2 = null;

// Rota para exibir o formulário de login
app.get("/LoginDogWalker.html", (req, res) => {
  res.sendFile(__dirname + "/LoginDogWalker.html"); // Caminho para o arquivo HTML de login
});

// Rota para processar o login
app.post("/logindogwalker", (req, res) => {
  const { usuario, senha } = req.body;

  // Validação dos campos
  if (!usuario || !senha) {
    return res
      .status(400)
      .json({ message: "Usuário e senha são obrigatórios!" });
  }

  // Verificar se o usuário e senha estão corretos no banco de dados
  const query = `SELECT * FROM dogwalkers WHERE usuario = ? AND senha = ?`;
  db.get(query, [usuario, senha], (err, row) => {
    if (err) {
      console.error("Erro ao buscar dados no banco de dados:", err.message);
      return res
        .status(500)
        .json({ message: "Erro no servidor. Tente novamente mais tarde." });
    }

    if (row) {
      // Login bem-sucedido: armazenar os dados do usuário no servidor
      usuarioLogado2 = {
        id: row.id,
        nome: row.nome,
        email: row.email,
        usuario: row.usuario,
        senha: row.senha, // Evite salvar senhas em produção; isso é só para teste
      };

      IdDog = usuarioLogado2.id; // Atribuição global
      NomeDog = usuarioLogado2.nome

      console.log("Usuário logado:", usuarioLogado2);

      return res.json({
        message: "Login bem-sucedido!",
        user: usuarioLogado2, // Enviar os dados do usuário para o cliente
      });
    } else {
      // Login falhou
      return res.status(401).json({ message: "Usuário ou senha inválidos!" });
    }
  });
});

// Supondo que "Nome" é a variável global no banco
app.get('/getUserNameDog', (req, res) => {
    if (NomeDog) {
        res.json({ nome: NomeDog });
    } else {
        res.status(404).json({ error: 'Nome não encontrado' });
    }
});


//Os dogão né pai, receba siuuuuuuuuuuuuuuuuuuuuuuuu

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/CadastroDog.html"); // Certifique-se de que o HTML está no mesmo diretório
});

// Rota para receber o formulário de cadastro de cachorro
app.post("/cadastrodog", upload.single("dog-image"), (req, res) => {
  const {
    "dog-name": dogName,
    "dog-breed": dogBreed,
    "dog-age": dogAge,
    "dog-history": dogHistory,
    "dog-care": dogCare,
  } = req.body;

  // Obtenção do ID do dono, que pode vir de uma sessão ou de um objeto global
  // Aqui, estamos simulando que o "usuarioLogado" tem o id do dono.

  // Informações sobre a imagem
  const dogImage = req.file ? req.file.filename : null; // Nome do arquivo da imagem

  // Verificando se todos os campos obrigatórios foram preenchidos
  if (
    !dogName ||
    !dogBreed ||
    !dogAge ||
    !dogHistory ||
    !dogCare ||
    !dogImage
  ) {
    return res.status(400).json({
      success: false,
      message: "Todos os campos são obrigatórios, incluindo a imagem!",
    });
  }

  // Log dos dados recebidos
  console.log("Dados recebidos:");
  console.log("Nome do Cachorro:", dogName);
  console.log("Raça:", dogBreed);
  console.log("Idade:", dogAge);
  console.log("Histórico Hospitalar:", dogHistory);
  console.log("Cuidados Especiais:", dogCare);
  console.log("Imagem:", dogImage);
  console.log("ID do Dono:", usuarioLogado.id);

  // Preparar a consulta SQL para inserir os dados no banco de dados
  const sql = `INSERT INTO dogs (nome, raca, idade, historico, cuidados, imagem, id_dono) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)`;

  const params = [
    dogName,
    dogBreed,
    dogAge,
    dogHistory,
    dogCare,
    dogImage,
    usuarioLogado.id,
  ];

  // Log da consulta SQL que será executada
  console.log("Consulta SQL:", sql);
  console.log("Parâmetros:", params);

  // Executar a consulta no banco de dados
  db.run(sql, params, function (err) {
    if (err) {
      console.error("Erro ao inserir dados no banco:", err.message);
      return res
        .status(500)
        .json({ success: false, message: "Erro ao cadastrar cachorro!" });
    }

    // Caso a inserção seja bem-sucedida, enviar resposta de sucesso
    console.log("Cachorro cadastrado com sucesso!");
    res.json({ success: true, message: "Cachorro cadastrado com sucesso!" });
  });
});

// Rota para buscar dados dos cachorros
app.get("/BuscaDog", (req, res) => {
  const db = new sqlite3.Database("DBClientes.db", (err) => {
    if (err) {
      console.error("Erro ao conectar:", err.message);
      res.status(500).json({
        success: false,
        message: "Erro ao conectar ao banco de dados",
      });
      return;
    }
  });

  db.all(
    "SELECT id, nome, raca, idade, imagem FROM dogs WHERE id_dono = ?",
    [idUsuario],
    (err, rows) => {
      if (err) {
        console.error("Erro ao consultar:", err.message);
        res.status(500).json({ success: false, message: "Erro na consulta" });
      } else {
        const quantidade = rows.length;
        res.json({ success: true, quantidade, dogs: rows });
      }
      db.close();
    }
  );
});

// Rota para lidar com o pedido
app.post("/pedido", (req, res) => {
  const {
    selectedDogIds,
    count,
    startAddress,
    endAddress,
    startCoords,
    endCoords,
    distance,
    price,
  } = req.body;

  // Converter os IDs dos cães para uma string separada por vírgulas
  const idDosCaes = selectedDogIds.join(",");

  // Preparar a query para inserção
  const query = `
      INSERT INTO pedidos (
        id_usuario,
        id_dos_caes,
        endereco_inicial,
        coordenadas_iniciais,
        endereco_final,
        coordenadas_finais,
        total_de_caes,
        preco,
        distancia
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

  // Executar a query
  db.run(
    query,
    [
      idUsuario,
      idDosCaes,
      startAddress,
      startCoords.join(","),
      endAddress,
      endCoords.join(","),
      count,
      price,
      distance,
    ],
    function (err) {
      if (err) {
        console.error("Erro ao inserir pedido no banco de dados:", err.message);
        return res
          .status(500)
          .json({ success: false, error: "Erro ao salvar pedido." });
      }

      // Log dos dados para o console
      console.log("Pedido salvo com sucesso:");
      console.log({
        idUsuario,
        idDosCaes,
        startAddress,
        startCoords,
        endAddress,
        endCoords,
        count,
        price,
        distance,
      });

      res.json({ success: true, message: "Pedido salvo com sucesso." });
    }
  );
});

// Parte dos Pedidos né pai

// Rota para obter as coordenadas e seus IDs da tabela pedidos
app.get("/obterCoordenadas", (req, res) => {
    const query = `SELECT id, coordenadas_iniciais FROM pedidos`;

    db.all(query, [], (err, rows) => {
        if (err) {
            console.error("Erro ao buscar coordenadas:", err.message);
            return res.status(500).json({ message: "Erro no servidor." });
        }

        // Formatar as coordenadas e IDs em um array de objetos
        const coordenadas = rows
            .map(row => {
                try {
                    // Dividir e converter a string em números
                    const [longitude, latitude] = row.coordenadas_iniciais.split(',').map(Number);
                    return { id: row.id, coordenada: [longitude, latitude] };
                } catch (error) {
                    console.error("Erro ao processar coordenadas:", row, error);
                    return null;
                }
            })
            .filter(coord => coord !== null); // Filtrar valores inválidos

        // Logar as coordenadas para visualização
        console.log("Coordenadas obtidas:", coordenadas);

        res.json(coordenadas);
    });
});





// Rota para obter detalhes de um pedido
app.get("/pedido/:id", (req, res) => {
    const pedidoId = req.params.id;

    // Consulta inicial para obter os dados do pedido na tabela 'pedidos'
    const queryPedido = `
        SELECT id_usuario, id_dos_caes, preco, endereco_inicial 
        FROM pedidos 
        WHERE id = ?;
    `;

    db.get(queryPedido, [pedidoId], (err, pedido) => {
        if (err) {
            console.error("Erro ao buscar dados do pedido:", err.message);
            res.status(500).json({ error: "Erro ao buscar dados do pedido." });
            return;
        }

        if (!pedido) {
            res.status(404).json({ error: "Pedido não encontrado." });
            return;
        }

        const { id_usuario, id_dos_caes, preco, endereco_inicial } = pedido;

        // Consulta para obter o nome do cliente na tabela 'dbclientes'
        const queryCliente = `
            SELECT nome 
            FROM dbclientes 
            WHERE id = ?;
        `;

        db.get(queryCliente, [id_usuario], (err, cliente) => {
            if (err) {
                console.error("Erro ao buscar dados do cliente:", err.message);
                res.status(500).json({ error: "Erro ao buscar dados do cliente." });
                return;
            }

            if (!cliente) {
                res.status(404).json({ error: "Cliente não encontrado." });
                return;
            }

            const nomeCliente = cliente.nome;

            // Consulta para obter os dados do cachorro na tabela 'dogs'
            const queryDog = `
                SELECT 
                    nome AS nomeCachorro, 
                    raca AS racaCachorro, 
                    idade AS idadeCachorro, 
                    imagem AS fotoCachorro 
                FROM dogs 
                WHERE id = ?;
            `;

            db.get(queryDog, [id_dos_caes], (err, dog) => {
                if (err) {
                    console.error("Erro ao buscar dados do cachorro:", err.message);
                    res.status(500).json({ error: "Erro ao buscar dados do cachorro." });
                    return;
                }

                if (!dog) {
                    res.status(404).json({ error: "Cachorro não encontrado." });
                    return;
                }

                const { nomeCachorro, racaCachorro, idadeCachorro, fotoCachorro } = dog;

                // Formata o preço para exibição como moeda brasileira
                const precoFormatado = preco.toLocaleString('pt-BR', {
                    style: 'currency',
                    currency: 'BRL',
                });

                // Construindo o caminho completo da imagem
                const fotoUrl = fotoCachorro
                    ? `http://localhost:3000/uploads/${fotoCachorro}`
                    : null;

                // Exibindo os dados no log do servidor
                console.log("Detalhes do Pedido:");
                console.log(`Cliente: ${nomeCliente}`);
                console.log(`Endereço Inicial: ${endereco_inicial}`);
                console.log(`Cachorro: ${nomeCachorro}`);
                console.log(`Raça: ${racaCachorro}`);
                console.log(`Idade: ${idadeCachorro} anos`);
                console.log(`Preço: ${precoFormatado}`);
                console.log(`Foto: ${fotoUrl}`);

                // Retornando os dados como resposta JSON
                res.json({
                    nomeCliente,
                    endereco: endereco_inicial,
                    nomeCachorro,
                    racaCachorro,
                    idadeCachorro,
                    fotoCachorro: fotoUrl,
                    preco: precoFormatado,
                });
            });
        });
    });
});




function AceitarPedido() {

    pedidoId = null;
// Rota para aceitar um pedido
app.post('/aceitarPedido/:idPedido', (req, res) => {
    const pedidoId = req.params.idPedido;

    console.log(`Recebendo pedido com ID: ${pedidoId}`); // Log para garantir que o pedidoId foi recebido corretamente

    // Consultar a tabela pedidos para obter os dados relacionados ao pedido
    db.get(`SELECT id_usuario, id_dos_caes, endereco_inicial, coordenadas_iniciais, endereco_final, coordenadas_finais, preco FROM pedidos WHERE id = ?`, [pedidoId], (err, pedido) => {
        if (err) {
            console.error("Erro ao consultar pedido:", err);
            return res.status(500).json({ success: false, message: "Erro ao buscar dados do pedido." });
        }

        if (!pedido) {
            console.log(`Pedido ${pedidoId} não encontrado`); // Log para verificar se o pedido existe
            return res.status(404).json({ success: false, message: "Pedido não encontrado." });
        }

        // Consultar o nome do usuário na tabela dbclientes
        db.get(`SELECT nome FROM dbclientes WHERE id = ?`, [pedido.id_usuario], (err, usuario) => {
            if (err) {
                console.error("Erro ao consultar usuário:", err);
                return res.status(500).json({ success: false, message: "Erro ao buscar dados do usuário." });
            }

            if (!usuario) {
                console.log(`Usuário com ID ${pedido.id_usuario} não encontrado`); // Log para verificar se o usuário existe
                return res.status(404).json({ success: false, message: "Usuário não encontrado." });
            }

            // Consultar os dados do cachorro na tabela dbcaes
            db.get(`SELECT nome, raca, idade, historico, cuidados, imagem FROM dogs WHERE id = ?`, [pedido.id_dos_caes], (err, cachorro) => {
                if (err) {
                    console.error("Erro ao consultar cachorro:", err);
                    return res.status(500).json({ success: false, message: "Erro ao buscar dados do cachorro." });
                }

                if (!cachorro) {
                    console.log(`Cachorro com ID ${pedido.id_dos_caes} não encontrado`); // Log para verificar se o cachorro existe
                    return res.status(404).json({ success: false, message: "Cachorro não encontrado." });
                }

                db.run(`INSERT INTO pedidos_aceitos 
                    (pedido_id, id_usuario, nome_usuario, id_cachorro, nome_cachorro, raca, idade, historico, cuidados, imagem, endereco_inicial, coordenadas_iniciais, endereco_final, coordenadas_finais, preco, iddogwalker, nome_dogwalker) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [pedidoId, pedido.id_usuario, usuario.nome, pedido.id_dos_caes, cachorro.nome, cachorro.raca, cachorro.idade, cachorro.historico, cachorro.cuidados, cachorro.imagem, pedido.endereco_inicial, pedido.coordenadas_iniciais, pedido.endereco_final, pedido.coordenadas_finais, pedido.preco, IdDog, NomeDog], // Inclua NomeDog aqui
                    (err) => {
                    if (err) {
                        console.error("Erro ao inserir dados na tabela pedidos_aceitos:", err);
                        return res.status(500).json({ success: false, message: "Erro ao registrar o pedido." });
                    }

                    console.log(`Inserção realizada com sucesso na tabela pedidos_aceitos.`); // Log para confirmar inserção

                    // Excluir os dados do pedido na tabela pedidos após a inserção
                    db.run(`DELETE FROM pedidos WHERE id = ?`, [pedidoId], (err) => {
                        if (err) {
                            console.error("Erro ao excluir pedido:", err);
                            return res.status(500).json({ success: false, message: "Erro ao excluir o pedido da tabela pedidos." });
                        }

                        console.log(`Pedido ${pedidoId} excluído com sucesso da tabela pedidos.`); // Log de sucesso na exclusão

                        // Exibir os dados no log
                        console.log(`Pedido ${pedidoId} aceito com sucesso!`);
                        console.log(`Dados do Pedido:`, pedido);
                        console.log(`Dados do Usuário:`, usuario);
                        console.log(`Dados do Cachorro:`, cachorro);

                          // Agora, chamamos a função que você deseja executar
                          FuncaoNomeDog(pedidoId); // Passa o nome do cachorro para a função

                        // Retornar a resposta de sucesso
                        res.json({ success: true, message: `Pedido ${pedidoId} aceito com sucesso!` });
                    });
                });
            });
        });
    });
});

FuncaoNomeDog(pedidoId);

}


function FuncaoNomeDog(pedidoId) {
    console.log(`Buscando o nome do DogWalker para o pedido...`);

    // Agora podemos usar o pedidoId diretamente
    db.get(`SELECT nome_dogwalker FROM pedidos_aceitos WHERE pedido_id = ?`, [pedidoId], (err, result) => {
        if (err) {
            console.error("Erro ao consultar DogWalker:", err);
            return;
        }

        if (!result || !result.nome_dogwalker) {
            console.log(`Nome do DogWalker não encontrado para o pedido ${pedidoId}.`);
            return;
        }

        const nomeDogWalker = result.nome_dogwalker;
        console.log(`Nome do DogWalker encontrado: ${nomeDogWalker}`);

        // Enviar o nome do DogWalker para a rota
        fetch('http://localhost:3000/enviarNomeDog', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ NomeDogWalker: nomeDogWalker })  // Envia o nome do DogWalker como JSON
        })
        .then(response => response.json())
        .then(data => {
            console.log('Resposta da rota:', data);
        })
        .catch(error => {
            console.error('Erro ao enviar o nome para a rota:', error);
        });
    });
}

AceitarPedido();



app.get('/pedidoEmAndamento', (req, res) => {
    if (!IdDog) {
        console.error("A variável global IdDog não está definida.");
        return res.status(500).json({ success: false, message: "Erro interno: IdDog não definido." });
    }

    db.get(
        `SELECT id, nome_usuario, nome_cachorro, raca, idade, historico, cuidados, imagem, endereco_inicial, coordenadas_iniciais, endereco_final, coordenadas_finais, preco 
         FROM pedidos_aceitos 
         WHERE iddogwalker = ? 
         ORDER BY data_aceite DESC 
         LIMIT 1`, 
        [IdDog],
        (err, pedido) => {
            if (err) {
                console.error("Erro ao consultar pedido:", err);
                return res.status(500).json({ success: false, message: "Erro ao buscar pedido em andamento." });
            }
            if (!pedido) {
                console.log(`Nenhum pedido encontrado para o iddogwalker ${IdDog}`);
                return res.status(404).json({ success: false, message: "Nenhum pedido em andamento encontrado." });
            }

            console.log("Pedido encontrado:", pedido); // Log para depuração

            pedido.coordenadas_iniciais = JSON.stringify(pedido.coordenadas_iniciais.split(',').map(Number));
            pedido.coordenadas_finais = JSON.stringify(pedido.coordenadas_finais.split(',').map(Number));
            pedido.imagem = `http://localhost:3000/uploads/${pedido.imagem}`;
            pedido.historico = pedido.historico || "Sem histórico.";
            pedido.cuidados = pedido.cuidados || "Sem cuidados específicos.";

            res.json({ success: true, pedido });
        }
    );
});

// Iniciando o servidor
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
